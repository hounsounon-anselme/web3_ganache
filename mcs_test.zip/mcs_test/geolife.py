import pandas as pd
import pandas as pd
import numpy as np
from math import radians, sin, cos, sqrt, atan2
import numpy as np




import pandas as pd
import numpy as np
from math import radians, sin, cos, sqrt, atan2

def laplace_distribution(mu, b):
    U = np.random.uniform(-1/2, 1/2)
    X = mu - b * np.sign(U) * np.log(1 - 2 * np.abs(U))
    return X

def haversine(lat1, lon1, lat2, lon2):
    R = 6371  # Rayon de la Terre en kilomètres
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    distance = R * c  # Distance en kilomètres
    return distance

def calculate_distances_and_add_noise(df):
    distances = [0]  # Commencer par 0 pour la première distance
    mu = 0
    b = 0  # Initialiser b à 0
    distancemax = 0  # Initialiser distancemax à 0

    new_latitudes = []
    new_longitudes = []

    for i in range(len(df)):
        if i > 0: 
            lat1, lon1 = df.iloc[i-1, 0], df.iloc[i-1, 1]
            lat2, lon2 = df.iloc[i, 0], df.iloc[i, 1]
            distance = haversine(lat1, lon1, lat2, lon2)
            distances.append(distance)

            if distance > distancemax:
                distancemax = distance
                b = 0.01 / 0.8  # Mettre à jour b

            noise_l = abs(laplace_distribution(mu, b))
            noise_la = laplace_distribution(mu, b)
            new_latitudes.append(lat1 + noise_l)
            new_longitudes.append(lon1 + noise_la)
        else:
            noise_l = abs(laplace_distribution(mu, b))
            new_latitudes.append(df.iloc[i, 0]+noise_l)
            new_longitudes.append(df.iloc[i, 1]+noise_l)

    df['new_latitude'] = new_latitudes
    df['new_longitude'] = new_longitudes
    df['distance_km'] = distances

    return df

# Lire les fichiers CSV et prendre uniquement les 30 premières lignes
data = pd.read_csv(r'c:\Users\ahounsounon\Downloads\Geolife Trajectories 1.3\Data\000\Trajectory\20081023025304.plt', skiprows=6, header=None).head(300)
data1 = pd.read_csv(r'c:\Users\ahounsounon\Downloads\Geolife Trajectories 1.3\Data\040\Trajectory\20090209043406.plt', skiprows=6, header=None).head(300)
data2 = pd.read_csv(r'c:\Users\ahounsounon\Downloads\Geolife Trajectories 1.3\Data\080\Trajectory\20070627094922.plt', skiprows=6, header=None).head(300)
data3 = pd.read_csv(r'c:\Users\ahounsounon\Downloads\Geolife Trajectories 1.3\Data\100\Trajectory\20110729124412.plt', skiprows=6, header=None).head(300)
data4 = pd.read_csv(r'c:\Users\ahounsounon\Downloads\Geolife Trajectories 1.3\Data\120\Trajectory\20090919071137.plt', skiprows=6, header=None).head(300)

# Ajouter une colonne pour identifier la source des données
data['source'] = 'Luc'
data1['source'] = 'Jean'
data2['source'] = 'Ana'
data3['source'] = 'Brice'
data4['source'] = 'Prince'

combined_data = pd.concat([data, data1, data2, data3, data4], ignore_index=True)

selected_data = combined_data[[0, 1, 5, 6, 'source']]

selected_data['datetime'] = pd.to_datetime(selected_data[5] + ' ' + selected_data[6])
selected_data = selected_data.drop([5, 6], axis=1)

selected_data = calculate_distances_and_add_noise(selected_data)

selected_data.to_csv('selected_data_with_noise.csv', index=False)
print(selected_data)


